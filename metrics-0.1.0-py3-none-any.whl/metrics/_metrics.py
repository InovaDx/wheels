from sklearn.metrics import confusion_matrix
from statsmodels.stats.contingency_tables import Table2x2
import numpy as np


def precision(y_target: np.array, y_pred: np.array) -> float:
    """ 
    Calculate precision of a model.
    
    Args:
        y_target (np.array): Target values.
        y_pred (np.array): Predicted values.
    
    Returns:
        float: Precision of the model.
    
    Raises:
        ValueError: If the number of samples in y_target and y_pred are different, 
            or if the values in y_pred are negative
    Examples:
    >>> y_target = np.array([0, 0, 1, 1])
    >>> y_pred = np.array([0, 0, 1, 1])
    >>> precision(y_target, y_pred)
    """
    if any(y_pred < 0):
        raise ValueError("y_pred must be non-negative")
    
    if any(np.isnan(y_pred)) or any(np.isinf(y_pred)):
        raise ValueError("y_pred cannot have nan values")
    
    conf_matrix = confusion_matrix(y_target, y_pred)
    _, fp, _, tp = conf_matrix.ravel()

    score = tp / (tp + fp)
    
    return score


def sensitivity(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    _, _, fn, tp = conf_matrix.ravel()

    score = tp / (tp + fn)
    
    if np.isnan(score) or np.isinf(score):
        score = 0
    
        
    return score

def specificity(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    tn, fp, _, _ = conf_matrix.ravel()

    score = tn / (fp + tn)

    if np.isnan(score) or np.isinf(score):
        score = 0
    
    return score

def accuracy(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    tn, _, _, tp = conf_matrix.ravel()
    n_all = sum(conf_matrix.ravel())
       
    score = (tn + tp) / n_all

    if np.isnan(score) or np.isinf(score):
        score = 0
    
    return score

def f1_score(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    _, fp, fn, tp = conf_matrix.ravel()

    score = 2 * ((tp / (tp + fp)) * (tp / (tp + fn))) / ((tp / (tp + fp)) + (tp / (tp + fn)))
    
    if np.isnan(score) or np.isinf(score):
        score = 0
    
    return score

def likelihood_ratio_pos(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    tn, fp, fn, tp = conf_matrix.ravel()
    
    score = (tp / (tp + fn)) / (1 - (tn / (fp + tn)))
    
    if np.isnan(score) or np.isinf(score):
        score = 0
    

    return score

def likelihood_ratio_neg(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    tn, fp, fn, tp = conf_matrix.ravel()

    score = (1 - (tp / (tp + fn))) / (tn / (fp + tn))
    
    if np.isnan(score) or np.isinf(score):
        score = 0
    
    
    return score

def odd_ratio(y_target,y_pred):
    conf_matrix = confusion_matrix(y_target, y_pred)
    score = Table2x2(conf_matrix).oddsratio

    if np.isnan(score) or np.isinf(score):
        score = 0
    
    return score
