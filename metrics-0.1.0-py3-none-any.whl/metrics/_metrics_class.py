import numpy as np
import pandas as pd


class Metric:
    def __init__(self, value, confidence_interval, alpha=0.05):
        self.value = value
        self.confidence_interval = confidence_interval
        self.alpha = alpha
        self.ci_pct = 1 - self.alpha
        self.interval = max(self.confidence_interval)-min(self.confidence_interval)
    
    def __str__(self):
        return f"{self.value:.3f} ({self.confidence_interval[0]:.3f} - {self.confidence_interval[1]:.3f})"

def calculate_metrics_with_CI(y_target:pd.DataFrame, y_pred:pd.DataFrame, alpha=0.05, epsilon=1e-2):
    """
    Intakes a confusion matrix from statsmodels and returns the associated metrics.
    Uses the Clopper-Pearson method (acceptable by CLSI guidelines) to calculate the
    confidence intervals of the appropriate metrics.
    Likelihood ratio confidence interval calculations attributed to
    https://www2.ccrb.cuhk.edu.hk/stat/confidence%20interval/Diagnostic%20Statistic.htm

    Args:
        conf_matrix (np.ndarray): statsmodels 2x2 confusion matrix
        alpha (float): 1 - confidence interval.
            Defaults to 0.05 for a confidence interval of 0.95

    Returns:
        tuple: accuracy, accuracy confidence interval, specificity,
             specificity confidence interval, sensitivity,
             sensitivity confidence interval, precision,
             precision confidence interval,
             negative likelihood ratio, positive likelihood ratio,
             odds ratio, odds ratio confidence interval
    """
    from scipy import stats
    from statsmodels.stats.proportion import proportion_confint
    from statsmodels.stats.contingency_tables import Table2x2
    from sklearn.metrics import confusion_matrix,roc_auc_score  
    
    ####Changes
    y_pred_round = np.round(y_pred)  
    
    conf_matrix = confusion_matrix(y_target, y_pred_round)
    
    tn, fp, fn, tp = conf_matrix.ravel()
    tn = max(tn, epsilon)
    fp = max(fp, epsilon)
    fn = max(fn, epsilon)
    tp = max(tp, epsilon)
    
    n_all = sum(conf_matrix.ravel())
        
    z_score = -stats.norm.ppf(alpha/2)

    # clopper pearson method from statsmodels
    
    sensitivity = Metric(tp / (tp + fn), proportion_confint(tp, tp + fn, method='beta', alpha=alpha), alpha)
    specificity = Metric(tn / (fp + tn), proportion_confint(tn, fp + tn, method='beta',alpha=alpha), alpha=alpha)
    precision = Metric(tp / (tp + fp), proportion_confint(tp, tp + fp, method='beta', alpha=alpha), alpha=alpha)
    accuracy = Metric((tn + tp) / n_all, proportion_confint(tn + tp, n_all, method='beta', alpha=alpha), alpha=alpha)
    
    f1_value = 2 * (precision.value * sensitivity.value) / (precision.value + sensitivity.value)
    f1_interval = z_score * np.sqrt((f1_value * (1 - f1_value)) / n_all)
    f1 = Metric(f1_value, (f1_value - f1_interval, f1_value+f1_interval), alpha=alpha)
    
    lr_pos_value = (sensitivity.value / max(1 - specificity.value, epsilon))
    lr_neg_value = ((1 - sensitivity.value) / max(specificity.value, epsilon))

    m1 = max(tp + fn, epsilon)
    m2 = max(fp + tn, epsilon)
    lr_pos_standard_error = np.sqrt((1 / tp) - (1 / m1) + (1 / fp) - (1 / m2))
    lr_neg_standard_error = np.sqrt((1 / fn) - (1 / m1) + (1 / tn) - (1 / m2))

    lr_pos = Metric(lr_pos_value, 
                    [np.exp(np.log(lr_pos_value) - (z_score * lr_pos_standard_error)),
                     np.exp(np.log(lr_pos_value) + (z_score * lr_pos_standard_error))],
                    alpha=alpha)
    lr_neg = Metric(lr_neg_value, 
                    [np.exp(np.log(lr_neg_value) - (z_score * lr_neg_standard_error)),
                     np.exp(np.log(lr_neg_value) + (z_score * lr_neg_standard_error))],
                    alpha=alpha)
    

    odds_ratio = Metric(Table2x2(conf_matrix).oddsratio,
                       Table2x2(conf_matrix).oddsratio_confint(),
                       alpha=alpha)
    if y_target.value_counts().shape[0] > 1:
        roc_auc = roc_auc_score(y_target, y_pred)
        roc_auc_ci = z_score * np.sqrt((roc_auc * (1 - roc_auc)) / n_all)
        roc_auc_upper_ci = np.clip(roc_auc + roc_auc_ci,0,1)
        roc_auc_lower_ci = np.clip(roc_auc - roc_auc_ci,0,1)
        roc_auc = Metric(roc_auc, (roc_auc_lower_ci, roc_auc_upper_ci), alpha=alpha)
    else:
        roc_auc = Metric(0, (0, 0), alpha=alpha)
        
    output = {'accuracy': accuracy,
              'specificity': specificity,
              'sensitivity': sensitivity,
              'precision': precision,
              'likelihood_ratio_neg': lr_neg,
              'likelihood_ratio_pos': lr_pos,
              'odd_ratio': odds_ratio,
              'f1_score': f1,
              'roc_auc_score': roc_auc}
    
    return output
